#!/usr/bin/env bash

# Similarly to data.sh, this script is mainly documentation of
# how to run all the experiments

conda activate curiosity

# This computes the like baseline and saves scores to
# like_majority_<fold>_metrics.json
./cli majority /data/users/shanemoon/experiments/

# da_majority_<fold>_metrics.json
./cli majority-da /data/users/shanemoon/experiments/

# policy_majority_<fold>_metrics.json
./cli majority-policy /data/users/shanemoon/experiments/

# Compute tfidf baseline
./cli fact-tfidf /data/users/shanemoon/dialog-data/folded/1127/tfidf.pickle  /data/users/shanemoon/dialog-data/folded/1127/wiki_sql.sqlite.db /data/users/shanemoon/experiments/

# Generate allennlp training configs
# These appear in `configs/generated`
./cli gen-configs /data/users/par/experiments/
