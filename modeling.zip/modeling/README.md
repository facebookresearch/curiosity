# Overview
This directory contains the allennlp-based data readers and models for the curiosity project.
The intent is that the entirety of this folder and the code that generates the paper
is open sourced (on overleaf currently)

Throughout readme, I make note of what things need to be updated for release.

## Installation

1. Install a recent version of anaconda python https://www.anaconda.com/distribution/

For CPU:

1. Create an anconda environment `conda env create -f environment.yaml` (creates an environment named curiosity)
2. Activate the environment, in fish shell this is `conda activate curiosity`

For GPU (not changed environemnt file):

1. Create an anconda environment `conda env create -f environment_gpu.yaml` (creates an environment named curiosity)
2. Activate the environment, in fish shell this is `conda activate curiosity`

# Data

## Dialogs
Data is stored at `/mnt/vol/gfsfblearner-carolina/users/par/dialog-data/folded/MMDD`.
- Use the most recent date stamp as the data source
- Note this location and change `configs/model.jsonnet` to match (train/val/test/test_zero data paths)
- The directory should also contain the correct version of `wiki_sql.sqlite.db`, this should exist in the same directory as the train/val/test/zero data.

TODO: For data release, change this path to `data/` and modify this readme with information on how to download

## Entity Linked Facts

Although the `wiki_sql.sqlite.db` stores the facts, it does not store the positions of each entity link.
For this, you need to use the jsonlines file from the entity linker.

## Wikipedia2Vec

* Download the embeddings with `wget http://wikipedia2vec.s3.amazonaws.com/models/en/2018-04-20/enwiki_20180420_100d.txt.bz2`
* Decompress: `bzip2 -d enwiki_20180420_100d.txt.bz2`
* Filter out non-entities with:
* `./cli filter-emb /data/users/par/enwiki_20180420_100d.txt /data/users/par/wiki2vec_entity_100d.txt`

## Training and Evaluating Models

Models are run using a combination of the `allennlp train`, `allennlp evaluate`, and `./cli` command (in this repository).

In our paper, we vary models according to two axes:
- Text encoder: glove+lstm or bert
- Feature ablations: everything and leave one out

The configuration `configs/model.jsonnet` is the parent configuration. This can be converted into the set of configurations in the paper by running:

```bash
$ ./cli gen-configs /data/users/par/experiments/
```

This generates configurations in `configs/generated/` and a run file `run_allennlp.sh` that lists the correct command to run each model variant. Generally, the commands look like this:

```bash
$ allennlp train --include-package curiosity -s /data/users/par/models/glove_bilstm -f configs/generated/glove_bilstm.json
$ allennlp evaluate --include-package curiosity --output-file /data/users/par/experiments/glove_bilstm_val_metrics.json /data/users/par/models/glove_bilstm /data/users/par/dialog-data/folded/1022/curiosity_dialogs.val.json
$ allennlp evaluate --include-package curiosity --output-file /data/users/par/experiments/glove_bilstm_test_metrics.json /data/users/par/models/glove_bilstm /data/users/par/dialog-data/folded/1022/curiosity_dialogs.test.json
$ allennlp evaluate --include-package curiosity --output-file /data/users/par/experiments/glove_bilstm_zero_metrics.json /data/users/par/models/glove_bilstm /data/users/par/dialog-data/folded/1022/curiosity_dialogs.test_zero.json
```

### Running on GPU
In addition to installing the gpu variant of the environment, to use the GPU you need to pass: `-o '{"trainer": {"cuda_device": 0}}'` to the `allennlp train` command. You should change the device number to match an open GPU.

## Export to Paper
The configuration generator also properly names files so that if you copy files with `ssh` as shown below, the results will automagically update the next time you run `make 2020_acl_curiosity.paper.pdf` in the repo:

```bash
scp 'devgpu006.atn5.facebook.com:/data/users/par/experiments/*' ~/code/curiosity-paper/2020_acl_curiosity/data/experiments/
```
Then be sure to commit those updates to the repository.

TODO: Update this section to explain thats how to reproduce paper results

## Tests

Since this code uses allennlp, and is thus not supported in fbcode by buck, tests aren't run automatically. Generally, its a good idea to run `pytest` to check that the (few) tests that there are pass, particularly for changes to the loss/metrics/reader

## Model Improvements

Dialog context:
- Currently, only a forward LSTM is used. Other choices may be better, like incorporating attention, using a forward-only looking transformer, or a bi-LSTM/GRU with proper masking to prevent peeking into the future
- Dialog context operates over the final hidden states of the text encoder, incorporating attention into this from the context might help

Text Representation:
- Model currently uses Glove + biLSTM to encode text.
- A good baseline to add would be bert (allennlp has builtin support)

Fact loss:
- Currently all logits/losses are computed independently, some sort of shared normalization might help make scores more reliable.
- a reranking loss might make more sense
- passing in the embedding of the prior message probably helps a lot (not just the dialog context up to the current time step)

## Adding new module

The easiest way to modify the model is to:
- If possible, add a parameter to `curiosity.model.CuriosityModel` that is a general version of it (eg, `Seq2VecEncoder` or `FactRanker`)
- Implement a module that implements its api (or use one/combination in allennlp), EG `curiosity.nn.MeanLogitRanker` implements `curiosity.nn.FactRanker`
- In the config `configs/bilstm.jsonnet`, name the implementaiton to use, eg the `fact_ranker` entry



